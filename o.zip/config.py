TOKEN = "" #токен BotFather
CRYPTO_TOKEN = "" #токен CreptoPay
LOG_CHANNEL =  #ЛОГИРОВАНИЕ
CHANNEL_BROKER =  #Посредник
MAIN_CHANNEL =  #основа
ADMINS = [] #список админов
CHECK_URL = "" #юрл счёта
MONEYBACK = 0 #процент манибэка от игры
