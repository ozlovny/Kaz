python -m venv venv
source venv/bin/activate  # On Windows use `venv\Scripts\activate`

pip install -r requirements.txt
pip install aiohttp==3.8.6
# Add other packages and versions your project requires
